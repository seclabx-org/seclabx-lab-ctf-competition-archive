#!/bin/bash

rm -f /init.sh

# Get the user
user=$(ls /home)

echo $A1CTF_FLAG > /flag
chmod 400 /flag
unset A1CTF_FLAG

php-fpm -D
nginx -g 'daemon off;'